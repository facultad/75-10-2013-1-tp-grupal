package ar.uba.fi.tecnicasdedisenio.grupo8.hypermarket.caja.excepciones;

public class DescuentoVentaNoCalculado extends RuntimeException {

}
