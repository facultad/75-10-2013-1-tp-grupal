package ar.uba.fi.tecnicasdedisenio.grupo8.hypermarket.estrategia;

import ar.uba.fi.tecnicasdedisenio.grupo8.hypermarket.caja.IVenta;

public interface IEstrategiaAplicacionCupones {

	double getImporteDescuento(IVenta venta);
	

}
