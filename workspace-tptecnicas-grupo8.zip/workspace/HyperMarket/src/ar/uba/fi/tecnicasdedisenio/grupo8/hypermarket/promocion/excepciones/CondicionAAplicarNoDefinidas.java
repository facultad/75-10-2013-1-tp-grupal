package ar.uba.fi.tecnicasdedisenio.grupo8.hypermarket.promocion.excepciones;

public class CondicionAAplicarNoDefinidas extends RuntimeException {

}
