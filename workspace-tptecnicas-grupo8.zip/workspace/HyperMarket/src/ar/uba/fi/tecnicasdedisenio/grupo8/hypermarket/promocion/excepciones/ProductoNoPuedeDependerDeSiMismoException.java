package ar.uba.fi.tecnicasdedisenio.grupo8.hypermarket.promocion.excepciones;

public class ProductoNoPuedeDependerDeSiMismoException extends RuntimeException {

}
