package ar.uba.fi.tecnicasdedisenio.grupo8.hypermarket.caja.excepciones;

public class DescuentoNoCalculadoException extends RuntimeException {

}
