package ar.uba.fi.tecnicasdedisenio.grupo8.hypermarket.caja.excepciones;

public class VentaNoIniciadaException extends RuntimeException {

}
