package ar.uba.fi.tecnicasdedisenio.grupo8.hypermarket.caja;

public interface IEntidadFinanciera extends Identificable {
	public String getNombreEntidad();
}
