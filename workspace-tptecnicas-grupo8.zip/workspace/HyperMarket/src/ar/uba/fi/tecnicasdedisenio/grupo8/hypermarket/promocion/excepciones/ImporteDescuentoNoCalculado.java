package ar.uba.fi.tecnicasdedisenio.grupo8.hypermarket.promocion.excepciones;

public class ImporteDescuentoNoCalculado extends RuntimeException {

}
