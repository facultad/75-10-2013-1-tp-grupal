package ar.uba.fi.tecnicasdedisenio.grupo8.hypermarket.caja.excepciones;

public class CajaCerradaException extends RuntimeException {

}
