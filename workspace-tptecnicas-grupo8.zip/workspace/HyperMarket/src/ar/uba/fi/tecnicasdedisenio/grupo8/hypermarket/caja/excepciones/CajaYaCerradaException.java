package ar.uba.fi.tecnicasdedisenio.grupo8.hypermarket.caja.excepciones;

public class CajaYaCerradaException extends RuntimeException {

}
